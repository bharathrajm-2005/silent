package com.example.silent

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScheduleAdapter(
    private val scheduleList: List<Schedule>,
    private val onDeleteClickListener: (Schedule) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.ScheduleViewHolder>() {

    class ScheduleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.tv_schedule_name)
        val scheduleTimeTextView: TextView = itemView.findViewById(R.id.tv_schedule_time)
        val daysTextView: TextView = itemView.findViewById(R.id.tv_schedule_days)
        val modeTextView: TextView = itemView.findViewById(R.id.tv_schedule_mode)
        val deleteButton: ImageButton = itemView.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScheduleViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_schedule, parent, false)
        return ScheduleViewHolder(view)
    }

    override fun onBindViewHolder(holder: ScheduleViewHolder, position: Int) {
        val schedule = scheduleList[position]

        holder.nameTextView.text = schedule.name
        holder.scheduleTimeTextView.text = "${formatTime(schedule.startTime)} - ${formatTime(schedule.endTime)}"
        holder.daysTextView.text = if (schedule.isEveryday) {
            "Everyday"
        } else {
            getDaysString(schedule.selectedDays)
        }
        holder.modeTextView.text = if (schedule.isVibrate) "Vibrate mode" else "Silent mode"

        holder.deleteButton.setOnClickListener {
            onDeleteClickListener(schedule)
        }
    }

    override fun getItemCount(): Int {
        return scheduleList.size
    }

    private fun formatTime(timeInMillis: Long): String {
        return SimpleDateFormat("HHH:mm", Locale.getDefault()).format(Date(timeInMillis))
    }

    private fun getDaysString(days: List<Int>): String {
        val dayNames = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return days.joinToString(", ") { dayNames[it] }
    }
}