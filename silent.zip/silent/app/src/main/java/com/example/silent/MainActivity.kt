package com.example.silent

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var scheduleAdapter: ScheduleAdapter
    private val scheduleList = mutableListOf<Schedule>()
    private lateinit var db: ScheduleDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = ScheduleDatabase.getDatabase(applicationContext)
        recyclerView = findViewById(R.id.recyclerView) // Fixed ID name
        val layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        scheduleAdapter = ScheduleAdapter(scheduleList) { schedule ->
            showDeleteConfirmationDialog(schedule)
        }
        recyclerView.adapter = scheduleAdapter

        requestExactAlarmPermission()
        loadSchedules()
    }

    private fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // Android 12+ (S)
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                startActivityForResult(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM), REQUEST_CODE_REQUEST_EXACT_ALARM)
            }
        }
    }

    private fun loadSchedules() {
        lifecycleScope.launch {
            val schedules = withContext(Dispatchers.IO) {
                db.scheduleDao().getAllSchedules()
            }
            withContext(Dispatchers.Main) {
                scheduleList.clear()
                scheduleList.addAll(schedules)
                scheduleAdapter.notifyDataSetChanged()
                updateScheduleVisibility()
            }
        }
    }

    // Add missing function
    private fun updateScheduleVisibility() {
        // Implement your logic here to update schedule visibility
        // For example, show a message if the list is empty
        // Or hide/show other UI elements based on schedule list state
    }

    // Add missing function
    private fun showDeleteConfirmationDialog(schedule: Schedule) {
        AlertDialog.Builder(this)
            .setTitle("Delete Schedule")
            .setMessage("Are you sure you want to delete this schedule?")
            .setPositiveButton("Delete") { _, _ ->
                deleteSchedule(schedule)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Add missing function
    private fun deleteSchedule(schedule: Schedule) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                db.scheduleDao().deleteSchedule(schedule)
            }
            loadSchedules()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_REQUEST_EXACT_ALARM && resultCode == RESULT_OK) {
            scheduleAlarms()
        }
    }

    private fun scheduleAlarms() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager

        scheduleList.forEach { schedule ->
            val startIntent = Intent(this, SilentModeReceiver::class.java).apply {
                action = "com.example.silent.ACTIVATE_SCHEDULE"
                putExtra("schedule", schedule)
                putExtra("action", if (schedule.isVibrate) "VIBRATE" else "SILENT")
            }

            val endIntent = Intent(this, SilentModeReceiver::class.java).apply {
                action = "com.example.silent.DEACTIVATE_SCHEDULE"
                putExtra("schedule", schedule)
                putExtra("action", "NORMAL")
            }

            val startPendingIntent = PendingIntent.getBroadcast(
                this,
                schedule.id.toInt(), // Use toInt() if you need an Int
                startIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val endPendingIntent = PendingIntent.getBroadcast(
                this,
                (schedule.id + 1000).toInt(), // Use toInt() if you need an Int
                endIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                schedule.startTime,
                startPendingIntent
            )

            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, // Fixed typo (was RTC_WAKE_UP)
                schedule.endTime,
                endPendingIntent
            )
        }
    }

    companion object {
        private const val REQUEST_CODE_REQUEST_EXACT_ALARM = 1
    }
}